
import { Component, OnInit } from '@angular/core';
import { TypePc } from '../model/type.model';
import { PcService } from '../services/pc';
import { CommonModule } from '@angular/common';
import { UpdateType } from '../update-type/update-type';

@Component({
  selector: 'app-liste-types',
  standalone: true,
  imports: [CommonModule, UpdateType],
  templateUrl: './liste-types.html',
  styles: ``
})
export class ListeTypes implements OnInit {

  types!: TypePc[];
  updatedType: TypePc = { "idType": 0, "nomType": "" };

  ajout: boolean = true;

  constructor(private pcService: PcService) { }

  ngOnInit(): void {
    this.types = this.pcService.listeTypes();
  }

  typeUpdated(type: TypePc) {
    console.log("Type updated event", type);

    if (this.ajout) {
      this.pcService.ajouterType(type);
    } else {
      this.pcService.modifierType(type);
    }

    this.chargerTypes();
  }

  chargerTypes() {
    this.types = this.pcService.listeTypes();
  }

  updateType(type: TypePc) {
    this.updatedType = { ...type };
    this.ajout = false;
  }
}
